#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_SERIAL_NUMBER						1
#define IDC_CANCEL                              40000
#define IDC_EDIT                                40002
#define IDC_OK                                  40003
